//
//  TableViewDelegate.swift
//  APITableView
//
//  Created by Paraíso, Gustavo Alexandre on 18/05/2023.
//

import UIKit

class TableViewDelegate: NSObject, UITableViewDelegate{
    
    var viewModel: TableViewModel!
    var viewCoordinator: TableViewCoordinator!
    var itemSingular: ItemSingular?
    
    //
    //TODO - meter no SingleItemViewModel
    
    func bindSingleItem(index: Int){
            
            let network = Network(
                host: "cf5dxst1y4.execute-api.eu-west-1.amazonaws.com",
                path: "/develop/product/\(index)",
                hasKey: true,
                apiKey: "I2tgdBezVY5rakqSWB3eo1Q8V8Sk0myg7rkYQFBV")

            
        network.getNetworkItem() {[weak self] products in
            if let products = products {
                print(products)
                self?.itemSingular = products
            }
        }
            
    }
    
    
    //
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        viewCoordinator.pushSingleItemView(item: viewModel.itemsArray[indexPath.row])
    }
}
